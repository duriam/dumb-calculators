# UnityCompileInBackground

You can start compiling without having to return focus to the Unity editor after changing the script.

[![](https://img.shields.io/github/release/baba-s/unity-compile-in-background.svg?label=latest%20version)](https://github.com/baba-s/unity-compile-in-background/releases)
[![](https://img.shields.io/github/release-date/baba-s/unity-compile-in-background.svg)](https://github.com/baba-s/unity-compile-in-background/releases)
![](https://img.shields.io/badge/Unity-2018.2%2B-red.svg)
![](https://img.shields.io/badge/.NET-3.5%2B-orange.svg)
[![](https://img.shields.io/github/license/baba-s/unity-compile-in-background.svg)](https://github.com/baba-s/unity-compile-in-background/blob/master/LICENSE)

## News ( 2019/5/1 )

![](https://cdn-ak.f.st-hatena.com/images/fotolife/b/baba_s/20190501/20190501174544.gif)

You do not need to use this repository as Visual Studio 2019 supports background compilation.

## Version

- Unity 2018.3.0f2

## Usage

![](https://cdn-ak.f.st-hatena.com/images/fotolife/b/baba_s/20181227/20181227150651.gif)

For example, if you edit and save the code in Visual Studio,   
compilation will start without returning to the Unity editor.  

For macOS user, please run "brew install fswatch".
