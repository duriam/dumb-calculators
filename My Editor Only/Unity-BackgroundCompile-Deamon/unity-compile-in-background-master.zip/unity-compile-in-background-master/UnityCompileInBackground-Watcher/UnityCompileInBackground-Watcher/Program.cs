﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace UnityCompileInBackground_Watcher
{
    public static class Program
    {
        private static int _waitTime;

        /// <summary>
        /// Entry point
        /// </summary>
        /// <param name="args"></param>
		private static void Main(string[] args)
        {
            var options = new string[] { "-p", "-w" };
            var result = options.ToDictionary(c => c.Substring(1), c => args.SkipWhile(a => a != c).Skip(1).FirstOrDefault());
            var path = result["p"];

            _waitTime = int.Parse(result["w"]);

            // Start monitoring files asynchronously
            var notifyFilter =
                NotifyFilters.LastAccess |
                NotifyFilters.LastWrite |
                NotifyFilters.FileName |
                NotifyFilters.DirectoryName;

            var watcher = new FileSystemWatcher(path, "*.cs")
            {
                NotifyFilter = notifyFilter,
                IncludeSubdirectories = true,
            };

            watcher.Changed += OnChanged;
            watcher.Created += OnChanged;
            watcher.Deleted += OnChanged;
            watcher.Renamed += OnRenamed;

            watcher.EnableRaisingEvents = true;

            // Deamon loop to continue monitoring asynchronously
            for (; ; ) { }
        }

        /// <summary>
        /// Called when a file changes
        /// </summary>
        private static async void OnChanged(object sender, FileSystemEventArgs e)
        {
            await Task.Delay(_waitTime);
            Console.WriteLine("OnChanged");
        }

        /// <summary>
        /// Called when a file is renamed
        /// </summary>
        private static async void OnRenamed(object sender, RenamedEventArgs e)
        {
            await Task.Delay(_waitTime);
            Console.WriteLine("OnRenamed");
        }
    }
}
