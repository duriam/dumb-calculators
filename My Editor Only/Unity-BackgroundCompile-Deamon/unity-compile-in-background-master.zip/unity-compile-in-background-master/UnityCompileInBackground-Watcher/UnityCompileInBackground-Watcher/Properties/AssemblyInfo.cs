﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General information about the assembly is controlled through the following set of attributes:
// To change the information associated with an assembly,
// Change these attribute values.
[assembly: AssemblyTitle("Unity-CompileInBackground-Watcher")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Unity-CompileInBackground-Watcher")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// If ComVisible is set to false, the types in this assembly will be
// Not be able to be referenced. If you need to access the types in this assembly from COM,
// Set the type's ComVisible attribute to true.
[assembly: ComVisible(false)]

// If this project is published to COM, the following GUID will be the ID of the typelib
[assembly: Guid("747f2d50-5897-4263-8c18-0a3a2a0a537c")]

// Assembly version information consists of four values:
//
// major version
// minor version
// Build number
// Revision
//
// You can specify all values ​​or set the build number and revision number as default using
// can be default:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
